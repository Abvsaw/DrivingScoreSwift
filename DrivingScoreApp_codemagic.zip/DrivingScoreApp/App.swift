import SwiftUI

@main
struct DrivingScoreApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
